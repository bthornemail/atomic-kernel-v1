#!/usr/bin/env python3
import json
import hashlib
from dataclasses import dataclass

def mask(n: int, x: int) -> int:
    return x & ((1 << n) - 1)

def rotl(n: int, x: int, k: int) -> int:
    k %= n
    return mask(n, ((x << k) | (x >> (n - k))))

def rotr(n: int, x: int, k: int) -> int:
    k %= n
    return mask(n, ((x >> k) | (x << (n - k))))

def constant_of_width(n: int) -> int:
    return int.from_bytes(bytes([0x1D]) * (n // 8), "big")

def delta(n: int, x: int) -> int:
    return mask(n, rotl(n, x, 1) ^ rotl(n, x, 3) ^ rotr(n, x, 2) ^ constant_of_width(n))

def classify(n: int, x: int) -> dict:
    width = 0 if x == 0 else x.bit_length()
    density = x.bit_count()
    texture = sum((((x >> i) & 1) != ((x >> ((i + 1) % n)) & 1)) for i in range(n))
    return {"width": width, "density": density, "texture": texture}

def sequence(n: int, seed: int, steps: int) -> list[int]:
    out = []
    x = seed
    for _ in range(steps):
        out.append(x)
        x = delta(n, x)
    return out

def derive_seed(width: int, unicode_version: str, utf_ebcdic_artifact: str, normalization: str, context: str) -> int:
    payload = f"{unicode_version}|{utf_ebcdic_artifact}|{normalization}|{context}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest(), "big") & ((1 << width) - 1)
