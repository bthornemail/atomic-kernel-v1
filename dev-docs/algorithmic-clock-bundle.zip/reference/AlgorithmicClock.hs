module AlgorithmicClock where

import Data.Bits
import Numeric (showHex)

mask :: Integer -> Integer -> Integer
mask n x = x .&. ((1 `shiftL` fromInteger n) - 1)

rotl :: Integer -> Integer -> Integer -> Integer
rotl n x k =
  let k' = fromInteger (k `mod` n)
      n' = fromInteger n
  in mask n ((x `shiftL` k') .|. (x `shiftR` (n' - k')))

rotr :: Integer -> Integer -> Integer -> Integer
rotr n x k =
  let k' = fromInteger (k `mod` n)
      n' = fromInteger n
  in mask n ((x `shiftR` k') .|. (x `shiftL` (n' - k')))

constantOfWidth :: Integer -> Integer
constantOfWidth n =
  let bytes = fromInteger (n `div` 8)
  in foldl (cc _ -> (acc `shiftL` 8) .|. 0x1D) 0 [1..bytes]

delta :: Integer -> Integer -> Integer
delta n x = mask n (rotl n x 1 `xor` rotl n x 3 `xor` rotr n x 2 `xor` constantOfWidth n)
